module.exports = {
  // debug: process.env.NODE_ENV === 'development',
  debug: false,
  i18n: {
    defaultLocale: 'en',
    locales: ['en', 'pt-BR'],
  },
  reloadOnPrerender: true,
}
